// tests/prices.test.js
describe('Price requires justification', ()=>{
  it('rejects reduced tariff without justification', async ()=>{
    // POST renewal without justification on requiresJustification=true -> 400
  });
});
